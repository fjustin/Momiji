$(function(){
    $('.slide_body').bxSlider({
        slideWidth: 800,
        minSlides: 3,
        maxSlides: 3,
        moveSlides: 1,
        slideMargin: 0,
        auto: true
    });
});
